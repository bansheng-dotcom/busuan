"""
太乙神數 × 現代運籌博弈分析模組
==============================

此處以古法「推主客相闗法」及「七大兵法格局」為本，輔以現代零和博弈論（Zero-Sum
Game Theory）及線性規劃（Linear Programming）運籌博弈原理，計算主客雙方在各種
兵法策略下的 Nash 均衡，並求解主方最大期望勝率之最優混合策略。

核心原理：
  - 古法「推主客相闗法」提供主客勝負的定性結論（主勝 / 客勝 / 和）
  - 「主算 / 客算」提供兵力算數之量化比（payoff 基準）
  - 「七大兵法格局」（雷公入水、臨津問道等）各對應一種古典作戰模式，映射為現代
    博弈論的純策略（Pure Strategy），組合成零和支付矩陣（Payoff Matrix）
  - 純 Python 線性規劃（單形法）求解混合策略 Nash 均衡
  - 線性規劃求主方「最大期望勝率」之最優混合比例
"""

from __future__ import annotations

from typing import Any

import numpy as np

# ---------------------------------------------------------------------------
# 常數定義
# ---------------------------------------------------------------------------

# 主方四大兵法策略（古稱）
# 此處以古法兵書所載四種主要戰術為本，輔以現代博弈論純策略（Pure Strategy）分類原理
主方策略列: list[str] = [
    "謀攻（智取）",  # 策略 0：以謀略取勝，側重攻心
    "正攻（硬打）",  # 策略 1：正面強攻，兵力正面對撼
    "奇兵（偷襲）",  # 策略 2：奇兵突進，側翼奇襲
    "守勢（固守）",  # 策略 3：以靜制動，以守待攻
]

# 客方四大兵法策略（與主方對稱，客方視角）
客方策略列: list[str] = [
    "謀攻（智取）",
    "正攻（硬打）",
    "奇兵（偷襲）",
    "守勢（固守）",
]

# 古法「推主客相闗法」結論 → 支付矩陣基礎強度
# 此處以古法「推主客相闗法」吉凶定性為本，輔以博弈論支付函數（Payoff Function）量化原理
_主客相闗強度: dict[str | None, float] = {
    "主勝": 2.0,
    "客勝": -2.0,
    "主將囚，不利主": -3.0,
    "和": 0.0,
}

# 古法「七大兵法」格局名稱 → (主方策略索引, 客方策略索引, 調整量)
# 此處以古法七大兵法格局（雷公入水、臨津問道等）為本，
# 輔以現代博弈論策略對（Strategy Profile）調整原理
# 說明：每種兵法格局「成局」時，對特定策略組合增益 +調整量；「不成」則方向相反
_七大兵法策略映射: dict[str, tuple[int, int, float]] = {
    "推雷公入水": (0, 2, 1.5),  # 謀攻 vs 客奇兵 → 主方謀攻克制客奇兵
    "推臨津問道": (1, 0, 1.0),  # 正攻 vs 客謀攻 → 主方正攻壓制客謀攻
    "推獅子反擲": (2, 1, 1.5),  # 奇兵 vs 客正攻 → 主方奇兵克制客正攻
    "推白雲捲空": (0, 3, 1.0),  # 謀攻 vs 客守勢 → 主方謀攻破客守勢
    "推猛虎相拒": (1, 2, -1.0),  # 正攻 vs 客奇兵 → 客奇兵反制主正攻
    "推白龍得雲": (2, 0, 1.0),  # 奇兵 vs 客謀攻 → 主方奇兵出奇制勝
    "推回軍無言": (3, 1, 1.0),  # 守勢 vs 客正攻 → 主方守勢消耗客正攻
}

# 「成」表示吉（兵法格局出現且正向），「不成」表示凶（方向反轉）
_兵法吉凶字串: set[str] = {"成", "吉", "正", "利"}

# 八門吉凶對主方謀攻策略的加成（此處以古法八門吉凶為本，輔以博弈論邊際效益原理）
_八門吉凶表: dict[str, float] = {
    "開": 1.0,
    "休": 0.5,
    "生": 1.0,
    "傷": -0.5,
    "杜": 0.0,
    "景": 0.5,
    "死": -1.0,
    "驚": -0.5,
}

# 太乙落宮（九宮）對策略列的加成映射
# 此處以古法九宮八卦方位吉凶為本，輔以博弈論位置效應（Positional Effect）原理
# 宮位 → (策略索引, 加成值)：落宮影響特定策略的效力
_太乙落宮策略加成: dict[int, list[tuple[int, float]]] = {
    1: [(3, 0.8)],  # 一宮坎水：守勢有利
    2: [(3, 0.5), (1, -0.3)],  # 二宮坤土：守勢稍利，正攻不利
    3: [(2, 0.8)],  # 三宮震木：奇兵有利
    4: [(0, 0.6), (2, 0.4)],  # 四宮巽木：謀攻與奇兵皆利
    6: [(1, 0.8)],  # 六宮乾金：正攻有利
    7: [(1, 0.5), (0, 0.3)],  # 七宮兌金：正攻與謀攻皆利
    8: [(3, 0.6), (0, 0.4)],  # 八宮艮土：守勢與謀攻皆利
    9: [(0, 0.8)],  # 九宮離火：謀攻有利
}

# 陽遁 / 陰遁對攻守取向的整體調節
# 此處以古法陽遁主攻、陰遁主守為本，輔以博弈論攻守傾向（Offensive/Defensive Bias）原理
_遁法攻守調節: dict[str, list[tuple[int, float]]] = {
    "陽": [(0, 0.3), (1, 0.4), (2, 0.2), (3, -0.3)],  # 陽遁利攻
    "陰": [(0, -0.2), (1, -0.3), (2, 0.2), (3, 0.5)],  # 陰遁利守
}

# 三才理年對策略層次的加成
# 此處以古法三才（天地人）年對應之治理層次為本，輔以博弈論層級優勢原理
_三才理年策略加成: dict[str, list[tuple[int, float]]] = {
    "理天": [(0, 0.5)],  # 理天：謀攻得天助
    "理地": [(3, 0.5)],  # 理地：守勢得地利
    "理人": [(1, 0.3), (2, 0.3)],  # 理人：正攻與奇兵得人和
}

# 八宮旺衰狀態 → 加成係數
# 此處以古法八宮旺相休囚為本，輔以博弈論環境因子調節原理
_八宮旺衰係數: dict[str, float] = {
    "旺": 1.0,
    "相": 0.5,
    "胎": 0.2,
    "沒": -0.3,
    "死": -0.8,
    "囚": -0.5,
    "休": 0.0,
    "廢": -0.4,
}


# ---------------------------------------------------------------------------
# 純 Python 線性規劃（單形法）求解器
# ---------------------------------------------------------------------------


class _LPResult:
    """模擬 scipy.optimize.linprog 回傳結果的簡易容器。"""

    __slots__ = ("success", "x", "fun")

    def __init__(self, success: bool, x: list[float], fun: float) -> None:
        self.success = success
        self.x = x
        self.fun = fun


def _simplex_lp(
    c: list[float],
    A_ub: list[list[float]] | None = None,
    b_ub: list[float] | None = None,
    A_eq: list[list[float]] | None = None,
    b_eq: list[float] | None = None,
    bounds: list[tuple[float | None, float | None]] | None = None,
) -> _LPResult:
    """
    純 Python 兩階段單形法（Two-Phase Simplex）線性規劃求解器。

    最小化 c^T x  subject to  A_ub x <= b_ub,  A_eq x = b_eq,  lb <= x <= ub

    此函式模擬 scipy.optimize.linprog 的介面，回傳具有 .success、.x、.fun
    屬性的 _LPResult 物件。適用於小規模 LP 問題（如 4×4 零和博弈）。

    參數
    ----
    c : list[float]
        目標函數係數向量（最小化）。
    A_ub : list[list[float]] | None
        不等式約束矩陣（≤）。
    b_ub : list[float] | None
        不等式約束右側值。
    A_eq : list[list[float]] | None
        等式約束矩陣。
    b_eq : list[float] | None
        等式約束右側值。
    bounds : list[tuple[float | None, float | None]] | None
        各變數的下界與上界；None 表示無界。

    回傳
    ----
    _LPResult
        具 .success（bool）、.x（list[float]）、.fun（float）屬性。
    """
    n_var = len(c)
    if A_ub is None:
        A_ub = []
        b_ub = []
    if A_eq is None:
        A_eq = []
        b_eq = []
    if bounds is None:
        bounds = [(0.0, None)] * n_var

    # --- 變數替換：將所有變數轉為非負變數 ---
    # 'shift': x = lo + x'   (lb 有限)
    # 'split': x = x_pos - x_neg  (lb = -inf, ub = None)
    # 'flip':  x = ub - x'   (lb = -inf, ub 有限)
    substitutions: list[tuple[str, float, int, int]] = []  # (mode, offset, idx1, idx2)
    extra_ub: list[tuple[int, float]] = []
    n_new = 0
    new_c: list[float] = []

    for i in range(n_var):
        lb, ub = bounds[i]
        if lb is None and ub is None:
            substitutions.append(("split", 0.0, n_new, n_new + 1))
            new_c.append(c[i])
            new_c.append(-c[i])
            n_new += 2
        elif lb is None:
            substitutions.append(("flip", ub, n_new, -1))
            new_c.append(-c[i])
            n_new += 1
        else:
            lo = lb if lb is not None else 0.0
            substitutions.append(("shift", lo, n_new, -1))
            new_c.append(c[i])
            n_new += 1
            if ub is not None:
                extra_ub.append((n_new - 1, ub - lo))

    def _transform(row: list[float], rhs: float) -> tuple[list[float], float]:
        nr = [0.0] * n_new
        nrhs = rhs
        for i in range(n_var):
            mode, offset, idx1, idx2 = substitutions[i]
            if mode == "shift":
                nr[idx1] += row[i]
                nrhs -= row[i] * offset
            elif mode == "split":
                nr[idx1] += row[i]
                nr[idx2] += -row[i]
            elif mode == "flip":
                nr[idx1] += -row[i]
                nrhs -= row[i] * offset
        return nr, nrhs

    # 轉換不等式約束
    all_A_ub: list[list[float]] = []
    all_b_ub: list[float] = []
    for k in range(len(A_ub)):
        nr, nrhs = _transform(A_ub[k], b_ub[k])
        all_A_ub.append(nr)
        all_b_ub.append(nrhs)
    for var_idx, ub_val in extra_ub:
        br = [0.0] * n_new
        br[var_idx] = 1.0
        all_A_ub.append(br)
        all_b_ub.append(ub_val)

    # 轉換等式約束
    all_A_eq: list[list[float]] = []
    all_b_eq: list[float] = []
    for k in range(len(A_eq)):
        nr, nrhs = _transform(A_eq[k], b_eq[k])
        all_A_eq.append(nr)
        all_b_eq.append(nrhs)

    # 目標函數常數偏移
    obj_offset = 0.0
    for i in range(n_var):
        mode, offset, _, _ = substitutions[i]
        if mode == "shift":
            obj_offset += c[i] * offset
        elif mode == "flip":
            obj_offset += c[i] * offset

    # --- 構建標準型表格 ---
    # 變數：[結構變數(n_new), slack(n_ineq), 人工變數(n_art)]
    n_ineq = len(all_A_ub)
    n_eq = len(all_A_eq)

    # 確定哪些不等式約束需要人工變數（b < 0）
    ineq_need_art = [all_b_ub[k] < 0 for k in range(n_ineq)]
    n_art = n_eq + sum(1 for x in ineq_need_art if x)

    total_vars = n_new + n_ineq + n_art
    art_start = n_new + n_ineq

    tableau: list[list[float]] = []
    rhs_list: list[float] = []
    basis: list[int] = []
    art_vars: list[int] = []

    # 不等式約束
    for k in range(n_ineq):
        row = [0.0] * total_vars
        b = all_b_ub[k]
        if b >= 0:
            for j in range(n_new):
                row[j] = all_A_ub[k][j]
            row[n_new + k] = 1.0  # slack
            basis.append(n_new + k)
        else:
            for j in range(n_new):
                row[j] = -all_A_ub[k][j]
            row[n_new + k] = 1.0  # slack 充當人工變數
            basis.append(n_new + k)
            art_vars.append(n_new + k)
        tableau.append(row)
        rhs_list.append(abs(b))

    # 等式約束（始終需人工變數）
    art_counter = 0
    for k in range(n_eq):
        row = [0.0] * total_vars
        b = all_b_eq[k]
        coeffs = all_A_eq[k]
        if b < 0:
            coeffs = [-v for v in coeffs]
            b = -b
        for j in range(n_new):
            row[j] = coeffs[j]
        row[art_start + art_counter] = 1.0
        basis.append(art_start + art_counter)
        art_vars.append(art_start + art_counter)
        art_counter += 1
        tableau.append(row)
        rhs_list.append(abs(b))

    n_rows = len(tableau)

    # --- Phase 1：最小化人工變數之和（若有） ---
    if art_vars:
        phase1_cost = [0.0] * total_vars
        for ai in art_vars:
            phase1_cost[ai] = 1.0

        reduced_cost = _compute_reduced_cost(tableau, basis, phase1_cost, total_vars, n_rows)
        _simplex_iterate(tableau, rhs_list, basis, reduced_cost, art_vars, total_vars, n_rows)

        # 檢查可行性
        phase1_opt = sum(phase1_cost[basis[r]] * rhs_list[r] for r in range(n_rows))
        if phase1_opt > 1e-7:
            return _LPResult(False, [0.0] * n_var, 0.0)

    # --- Phase 2：最小化原始目標 ---
    phase2_cost = [0.0] * total_vars
    for j in range(n_new):
        phase2_cost[j] = new_c[j]
    # 人工變數在 Phase 2 中禁止進基
    forbidden = list(art_vars)

    reduced_cost2 = _compute_reduced_cost(tableau, basis, phase2_cost, total_vars, n_rows)
    _simplex_iterate(tableau, rhs_list, basis, reduced_cost2, forbidden, total_vars, n_rows)

    # 提取解
    x_new = [0.0] * n_new
    for r in range(n_rows):
        if basis[r] < n_new:
            x_new[basis[r]] = rhs_list[r]

    # 還原到原始變數空間
    x_orig = [0.0] * n_var
    for i in range(n_var):
        mode, offset, idx1, idx2 = substitutions[i]
        if mode == "shift":
            x_orig[i] = offset + x_new[idx1]
        elif mode == "split":
            x_orig[i] = x_new[idx1] - x_new[idx2]
        elif mode == "flip":
            x_orig[i] = offset - x_new[idx1]

    fun = obj_offset + sum(c[i] * x_orig[i] for i in range(n_var))
    return _LPResult(True, x_orig, fun)


def _compute_reduced_cost(
    tableau: list[list[float]],
    basis: list[int],
    cost: list[float],
    n_cols: int,
    n_rows: int,
) -> list[float]:
    """計算單形法的 reduced cost 行（z_j - c_j）。"""
    reduced = [0.0] * n_cols
    for j in range(n_cols):
        z_j = 0.0
        for r in range(n_rows):
            z_j += cost[basis[r]] * tableau[r][j]
        reduced[j] = z_j - cost[j]
    return reduced


def _simplex_iterate(
    tableau: list[list[float]],
    rhs: list[float],
    basis: list[int],
    reduced_cost: list[float],
    forbidden: list[int],
    n_cols: int,
    n_rows: int,
) -> None:
    """
    執行單形法迭代，就地修改 tableau、rhs、basis、reduced_cost。

    使用 Bland 規則避免循環。

    參數
    ----
    tableau : 約束矩陣
    rhs : 右側值
    basis : 當前基變數索引列表
    reduced_cost : 目標行的 reduced cost（z_j - c_j）
    forbidden : 不允許進基的變數索引
    n_cols : 變數總數
    n_rows : 約束總數
    """
    eps = 1e-9
    max_iter = 1000
    forbidden_set = set(forbidden)

    for _ in range(max_iter):
        # Bland 規則：選最小索引的正 reduced cost 變數進基（最小化問題）
        pivot_col = -1
        for j in range(n_cols):
            if j in forbidden_set:
                continue
            if reduced_cost[j] > eps:
                pivot_col = j
                break

        if pivot_col == -1:
            break  # 最優解已達成（所有 reduced cost <= 0）

        # 最小比值測試
        pivot_row = -1
        min_ratio = float("inf")
        for r in range(n_rows):
            if tableau[r][pivot_col] > eps:
                ratio = rhs[r] / tableau[r][pivot_col]
                if ratio < min_ratio - eps:
                    min_ratio = ratio
                    pivot_row = r
                elif abs(ratio - min_ratio) < eps and pivot_row >= 0:
                    if basis[r] < basis[pivot_row]:
                        pivot_row = r

        if pivot_row == -1:
            return  # 無界問題

        # 旋轉操作
        pivot_val = tableau[pivot_row][pivot_col]
        for j in range(n_cols):
            tableau[pivot_row][j] /= pivot_val
        rhs[pivot_row] /= pivot_val

        for r in range(n_rows):
            if r == pivot_row:
                continue
            factor = tableau[r][pivot_col]
            if abs(factor) < eps:
                continue
            for j in range(n_cols):
                tableau[r][j] -= factor * tableau[pivot_row][j]
            rhs[r] -= factor * rhs[pivot_row]

        basis[pivot_row] = pivot_col

        # 更新 reduced cost
        factor = reduced_cost[pivot_col]
        for j in range(n_cols):
            reduced_cost[j] -= factor * tableau[pivot_row][j]


# ---------------------------------------------------------------------------
# 主類別：TaiyiGame
# ---------------------------------------------------------------------------


class TaiyiGame:
    """
    太乙神數博弈分析類別

    以 pan() 回傳的 result dict 為輸入，根據古法「推主客相闗法」及「七大兵法格局」
    自動建構零和支付矩陣，並以純 Python 線性規劃（單形法）計算純策略 / 混合策略
    Nash 均衡，提供主方最優混合策略及期望勝率。

    此處以古法太乙神數推演為本，輔以現代零和博弈論（Zero-Sum Game Theory）
    及線性規劃（Linear Programming）運籌博弈原理。

    參數
    ----
    pan_result : dict[str, Any]
        由 Taiyi.pan() 方法回傳的太乙排盤結果字典。

    屬性
    ----
    支付矩陣 : list[list[float]], shape (4, 4)
        主方視角零和支付矩陣（正值代表主方有利，負值代表客方有利）。
    主方均衡策略 : list[float], shape (4,)
        主方最優混合策略概率分佈。
    客方均衡策略 : list[float], shape (4,)
        客方最優混合策略概率分佈。
    博弈均衡值 : float
        博弈均衡（Game Value），即主方的期望支付值。
    """

    def __init__(self, pan_result: dict[str, Any]) -> None:
        """
        初始化 TaiyiGame，以 pan() 結果建構博弈模型。

        此處以古法太乙排盤推算為本，輔以現代博弈論零和矩陣博弈（Matrix Game）建模原理。

        參數
        ----
        pan_result : dict[str, Any]
            Taiyi.pan() 回傳的字典，需包含「推主客相闗法」、「主算」、「客算」、
            「八門值事」等古法關鍵欄位。
        """
        self._pan = pan_result
        self.支付矩陣: np.ndarray = np.array(self._建構支付矩陣(), dtype=float)
        game_val, 主策略, 客策略 = self._求Nash均衡()
        self.博弈均衡值: float = game_val
        self.主方均衡策略: np.ndarray = np.array(主策略, dtype=float)
        self.客方均衡策略: np.ndarray = np.array(客策略, dtype=float)

    # ------------------------------------------------------------------
    # 私有方法：支付矩陣建構
    # ------------------------------------------------------------------

    def _解析主客相闗強度(self) -> float:
        """
        解析古法「推主客相闗法」欄位，轉換為支付矩陣基礎強度值。

        此處以古法「推主客相闗法」主客勝負定性判斷為本，
        輔以博弈論支付函數基準值（Baseline Payoff）設定原理。

        回傳
        ----
        float
            基礎支付強度（正值主方有利，負值客方有利）。
        """
        zjf: str | None = self._pan.get("推主客相闗法")
        if zjf is None:
            return 0.0
        for key, val in _主客相闗強度.items():
            if key and key in zjf:
                return val
        return 0.0

    def _解析算數差值(self) -> float:
        """
        解析主算與客算的數值差，作為兵力強弱比較基準。

        此處以古法「主算 / 客算」算數多寡比較為本，
        輔以博弈論支付函數線性縮放（Linear Scaling）原理。

        回傳
        ----
        float
            (主算 - 客算) / (主算 + 客算) 歸一化差值，範圍 [-1, 1]。
        """
        home_cal_field = self._pan.get("主算")
        away_cal_field = self._pan.get("客算")
        try:
            home = float(home_cal_field[0]) if isinstance(home_cal_field, list) else float(home_cal_field or 0)
            away = float(away_cal_field[0]) if isinstance(away_cal_field, list) else float(away_cal_field or 0)
        except (TypeError, ValueError, IndexError):
            return 0.0
        total = home + away
        if total == 0:
            return 0.0
        return (home - away) / total  # 歸一化至 [-1, 1]

    def _解析八門值事加成(self) -> float:
        """
        解析「八門值事」欄位，得到對主方謀攻策略的加成。

        此處以古法「八門值事」吉凶配應為本，
        輔以博弈論邊際效益（Marginal Payoff）調整原理。

        回傳
        ----
        float
            八門吉凶加成值。
        """
        门: str | None = self._pan.get("八門值事")
        if not 门:
            return 0.0
        return _八門吉凶表.get(str(门).strip(), 0.0)

    def _解析太乙局數(self) -> tuple[int, str, str | None]:
        """
        解析「局式」欄位，取得局數、遁法（陽/陰）及三才理年。

        此處以古法太乙局數推演結果為本，輔以博弈論環境參數建模原理。

        回傳
        ----
        tuple[int, str, str | None]
            (局數 1-72, 遁法 "陽"/"陰", 三才理年 "理天"/"理地"/"理人" or None)
        """
        局式: dict | None = self._pan.get("局式")
        if not isinstance(局式, dict):
            return (0, "", None)
        文: str = 局式.get("文", "")
        數: int = int(局式.get("數", 0))
        年: str | None = 局式.get("年")
        遁法 = "陽" if "陽" in 文 else ("陰" if "陰" in 文 else "")
        return (數, 遁法, 年)

    def _解析太乙落宮(self) -> int:
        """
        解析「太乙落宮」欄位，取得太乙所在宮位（0-9）。

        此處以古法太乙落宮九宮方位為本，輔以博弈論位置效應建模原理。

        回傳
        ----
        int
            太乙所在宮位（0-9）。
        """
        落宮 = self._pan.get("太乙落宮")
        try:
            return int(落宮)
        except (TypeError, ValueError):
            return 0

    def _解析主客筭旺衰(self) -> tuple[float, float]:
        """
        解析主算與客算的旺衰狀態，轉換為策略加成。

        主算旺/客算衰 → 主方攻勢策略加成；
        主算衰/客算旺 → 客方反攻策略加成。

        此處以古法「主筭 / 客筭」旺衰描述為本，
        輔以博弈論軍力態勢（Force Posture）量化原理。

        回傳
        ----
        tuple[float, float]
            (主方旺衰加成, 客方旺衰加成)，正值利攻，負值利守。
        """
        主筭 = self._pan.get("主算")
        客筭 = self._pan.get("客算")

        def _解析旺衰(cal_field: Any) -> float:
            if not isinstance(cal_field, list) or len(cal_field) < 2:
                return 0.0
            desc = cal_field[1]
            desc_str = str(desc) if not isinstance(desc, list) else " ".join(str(d) for d in desc)
            if "旺" in desc_str or "三才足數" in desc_str:
                return 0.6
            if "上和" in desc_str:
                return 0.3
            if "下和" in desc_str:
                return 0.1
            if "純陽" in desc_str or "純陰" in desc_str:
                return -0.2
            if "衰" in desc_str or "無天" in desc_str or "無地" in desc_str or "無人" in desc_str:
                return -0.5
            return 0.0

        return (_解析旺衰(主筭), _解析旺衰(客筭))

    def _解析三門五將(self) -> float:
        """
        解析「推三門具不具」及「推五將發不發」欄位。

        三門具（不吉） → 主方守勢壓力增加
        五將不發 → 進攻策略受限

        此處以古法「三門具不具」與「五將發不發」軍事態勢為本，
        輔以博弈論策略可行域（Feasible Strategy Set）約束原理。

        回傳
        ----
        float
            綜合態勢加成值（正值利攻，負值利守）。
        """
        三門 = str(self._pan.get("推三門具不具", ""))
        五將 = str(self._pan.get("推五將發不發", ""))

        加成 = 0.0
        # 三門具 → 兵勢受制，不利主攻
        if "三門具" in 三門:
            加成 -= 0.4
        elif "三門不具" in 三門:
            加成 += 0.3

        # 五將不發 → 進攻受限
        if "五將不發" in 五將:
            加成 -= 0.5
        elif "五將發" in 五將:
            加成 += 0.4

        return 加成

    def _解析定算(self) -> float:
        """
        解析「定算」欄位，取得定算值對主方的加成。

        定算大 → 整體態勢有利；定算小 → 不利。

        此處以古法「定算」綜合判斷為本，輔以博弈論全局期望值調節原理。

        回傳
        ----
        float
            定算加成值。
        """
        定算 = self._pan.get("定算")
        try:
            val = float(定算[0]) if isinstance(定算, list) else float(定算 or 0)
        except (TypeError, ValueError, IndexError):
            return 0.0
        # 定算常見範圍 0~50+，以 25 為基準歸一化
        return (val - 25.0) / 50.0  # 約 [-0.5, 0.5]

    def _解析八宮旺衰(self) -> float:
        """
        解析「八宮旺衰」欄位，計算太乙落宮所在宮位的旺衰狀態加成。

        此處以古法八宮旺相休囚判斷為本，輔以博弈論環境因子（Environmental Factor）原理。

        回傳
        ----
        float
            太乙落宮之旺衰加成值。
        """
        八宮 = self._pan.get("八宮旺衰")
        if not isinstance(八宮, dict):
            return 0.0
        落宮 = self._解析太乙落宮()
        if 落宮 == 0:
            return 0.0
        狀態 = 八宮.get(落宮)
        if not 狀態:
            return 0.0
        return _八宮旺衰係數.get(str(狀態), 0.0)

    def _建構支付矩陣(self) -> list[list[float]]:
        """
        根據古法推算結果自動建構 4×4 零和支付矩陣。

        矩陣建構邏輯（主方視角）：
        1. 以「推主客相闗法」定性結論設定全矩陣基準偏移（base_offset）。
        2. 以「主算 / 客算」差值提供兵力優勢加成。
        3. 以「七大兵法格局」是否成局調整特定策略對的支付值。
        4. 以「八門值事」吉凶補正謀攻策略列。
        5. 以「太乙局數」遁法（陽/陰）調節攻守傾向。
        6. 以「太乙局數」三才理年加成對應策略層次。
        7. 以「太乙落宮」九宮方位加成對應策略。
        8. 以「主算 / 客算」旺衰描述加成攻守態勢。
        9. 以「推三門具不具」及「推五將發不發」約束策略可行域。
        10. 以「定算」綜合值調節全局期望。
        11. 以「八宮旺衰」中太乙落宮之旺衰狀態加成。

        此處以古法太乙神數推演核心要素為本，輔以現代博弈論
        零和支付矩陣（Zero-Sum Payoff Matrix）建構原理。

        回傳
        ----
        list[list[float]], shape (4, 4)
            主方視角支付矩陣。
        """
        # 基礎非對稱博弈結構（反映四大兵法策略間的本質制約關係）
        # 此處以古典兵法「攻守奇正」相互制約原理為本，輔以博弈論策略對（Strategy Profile）初始化
        base: list[list[float]] = [
            [0.0, 1.0, -1.0, 2.0],  # 謀攻 vs [謀、正、奇、守]
            [-1.0, 0.0, 2.0, 1.0],  # 正攻 vs [謀、正、奇、守]
            [1.0, -2.0, 0.0, 1.5],  # 奇兵 vs [謀、正、奇、守]
            [-2.0, -1.0, -1.5, 0.0],  # 守勢 vs [謀、正、奇、守]
        ]

        # 輔助函式：對整個矩陣加上一個純量偏移
        def _add_scalar(matrix: list[list[float]], val: float) -> None:
            for i in range(len(matrix)):
                for j in range(len(matrix[0])):
                    matrix[i][j] += val

        # 輔助函式：對某一列加上一個純量偏移
        def _add_scalar_to_row(matrix: list[list[float]], row: int, val: float) -> None:
            for j in range(len(matrix[row])):
                matrix[row][j] += val

        # 1. 主客相闗法：基準偏移
        # 此處以古法「推主客相闗法」主客強弱為本，輔以博弈論支付函數基準偏移原理
        base_offset = self._解析主客相闗強度()
        _add_scalar(base, base_offset)

        # 2. 算數差值：兵力強弱全局加成
        # 此處以古法「主算 / 客算」兵力算數比較為本，輔以博弈論支付函數縮放原理
        cal_delta = self._解析算數差值()
        _add_scalar(base, cal_delta * 1.5)  # 縮放至合理影響範圍

        # 3. 七大兵法格局調整
        # 此處以古法七大兵法格局（雷公入水等）是否成局為本，
        # 輔以博弈論策略對局部支付調整（Local Payoff Adjustment）原理
        for 法名, (row, col, delta) in _七大兵法策略映射.items():
            格局值: Any = self._pan.get(法名)
            if 格局值 is None:
                continue
            格局文字 = str(格局值)
            # 判斷兵法是否成局（含吉字則正向，否則反向）
            if any(吉 in 格局文字 for 吉 in _兵法吉凶字串):
                base[row][col] += delta
            else:
                base[row][col] -= delta * 0.5  # 不成局則反向但力度減半

        # 4. 八門值事補正謀攻策略列（策略索引 0：謀攻）
        # 此處以古法「八門值事」吉凶判斷為本，輔以博弈論邊際效益補正原理
        八門加成 = self._解析八門值事加成()
        _add_scalar_to_row(base, 0, 八門加成)  # 謀攻策略受八門吉凶直接影響

        # 5. 太乙局數：遁法攻守傾向調節
        # 此處以古法陽遁主攻、陰遁主守為本，輔以博弈論攻守傾向（Offensive/Defensive Bias）原理
        局數, 遁法, 三才理年 = self._解析太乙局數()
        if 遁法 in _遁法攻守調節:
            for 策略索引, 調節量 in _遁法攻守調節[遁法]:
                _add_scalar_to_row(base, 策略索引, 調節量)

        # 6. 太乙局數：三才理年策略層次加成
        # 此處以古法三才理天/理地/理人對應之治理層次為本，輔以博弈論層級優勢原理
        if 三才理年 in _三才理年策略加成:
            for 策略索引, 調節量 in _三才理年策略加成[三才理年]:
                _add_scalar_to_row(base, 策略索引, 調節量)

        # 7. 太乙落宮：九宮方位策略加成
        # 此處以古法太乙落宮九宮方位為本，輔以博弈論位置效應（Positional Effect）原理
        落宮 = self._解析太乙落宮()
        if 落宮 in _太乙落宮策略加成:
            for 策略索引, 調節量 in _太乙落宮策略加成[落宮]:
                _add_scalar_to_row(base, 策略索引, 調節量)

        # 8. 主客筭旺衰：軍力態勢加成
        # 此處以古法「主筭 / 客筭」旺衰描述為本，輔以博弈論軍力態勢量化原理
        主旺衰, 客旺衰 = self._解析主客筭旺衰()
        # 主筭旺 → 主方攻勢策略（謀攻 + 正攻）增益
        _add_scalar_to_row(base, 0, 主旺衰 * 0.5)
        _add_scalar_to_row(base, 1, 主旺衰 * 0.5)
        # 客筭旺 → 主方受壓，守勢策略需求增加（反向影響）
        _add_scalar_to_row(base, 2, -客旺衰 * 0.3)
        _add_scalar_to_row(base, 3, -客旺衰 * 0.3)

        # 9. 三門五將：策略可行域約束
        # 此處以古法「推三門具不具」與「推五將發不發」軍事態勢為本，
        # 輔以博弈論策略可行域約束原理
        三門五將加成 = self._解析三門五將()
        # 正值利攻 → 加成謀攻與正攻；負值利守 → 加成守勢
        if 三門五將加成 > 0:
            _add_scalar_to_row(base, 0, 三門五將加成 * 0.5)
            _add_scalar_to_row(base, 1, 三門五將加成 * 0.5)
        else:
            _add_scalar_to_row(base, 3, -三門五將加成 * 0.5)  # 負值取反為正
            _add_scalar_to_row(base, 2, -三門五將加成 * 0.3)

        # 10. 定算：全局期望值調節
        # 此處以古法「定算」綜合數值為本，輔以博弈論全局期望值偏移原理
        定算加成 = self._解析定算()
        _add_scalar(base, 定算加成)  # 全局性偏移

        # 11. 八宮旺衰：太乙落宮旺衰環境加成
        # 此處以古法八宮旺相休囚狀態為本，輔以博弈論環境因子原理
        旺衰加成 = self._解析八宮旺衰()
        _add_scalar(base, 旺衰加成 * 0.5)  # 旺衰影響全局但力度適中

        return base

    # ------------------------------------------------------------------
    # 私有方法：Nash 均衡求解
    # ------------------------------------------------------------------

    def _求Nash均衡(self) -> tuple[float, list[float], list[float]]:
        """
        以線性規劃（LP）求解零和博弈的混合策略 Nash 均衡。

        零和博弈 Nash 均衡等價於極小極大定理（Minimax Theorem）：
          - 主方（最大化方）：max v s.t. A^T p ≥ v·e, 1^T p = 1, p ≥ 0
          - 客方（最小化方）：min v s.t. A q ≤ v·e, 1^T q = 1, q ≥ 0

        此處以零和博弈極小極大定理（Minimax Theorem, von Neumann 1928）為本，
        輔以現代線性規劃（Linear Programming）數值求解原理。

        回傳
        ----
        tuple[float, list[float], list[float]]
            (博弈均衡值, 主方均衡策略概率向量, 客方均衡策略概率向量)
        """
        A = self.支付矩陣
        m = len(A)  # m=4 (主方策略數)
        n = len(A[0])  # n=4 (客方策略數)

        # ---- 主方 LP：max v ↔ min -v ----
        # 決策變數 x = [p_0, p_1, ..., p_{m-1}, v]
        # 此處以主方極小極大問題（Maximin Problem）為本，輔以線性規劃對偶理論（LP Duality）
        c_主 = [0.0] * m + [-1.0]  # 最小化 -v

        # 不等式約束：對每個客方策略 j，sum_i A[i,j] * p_i ≥ v
        # → -sum_i A[i,j] * p_i + v ≤ 0
        A_ub_主 = [[0.0] * (m + 1) for _ in range(n)]
        for j in range(n):
            col_j = [A[i][j] for i in range(m)]  # A[:, j]
            for i in range(m):
                A_ub_主[j][i] = -col_j[i]
            A_ub_主[j][m] = 1.0
        b_ub_主 = [0.0] * n

        # 等式約束：sum_i p_i = 1
        A_eq_主 = [[1.0] * m + [0.0]]
        b_eq_主 = [1.0]

        # 邊界：p_i ≥ 0, v 無界
        bounds_主 = [(0.0, None)] * m + [(None, None)]

        res_主 = _simplex_lp(c_主, A_ub=A_ub_主, b_ub=b_ub_主, A_eq=A_eq_主, b_eq=b_eq_主, bounds=bounds_主)

        if res_主.success:
            p_主 = [max(0.0, v) for v in res_主.x[:m]]
            s_主 = sum(p_主)
            p_主 = [v / s_主 for v in p_主] if s_主 > 0 else [1.0 / m] * m
            game_value: float = float(-res_主.fun)
        else:
            # LP 求解失敗時退化為均等混合策略
            p_主 = [1.0 / m] * m
            game_value = float(min(max(col) for col in zip(*A)))

        # ---- 客方 LP：min v ↔ min v ----
        # 決策變數 y = [q_0, q_1, ..., q_{n-1}, v]
        # 此處以客方極小化問題（Minimax Problem）為本，輔以線性規劃對偶理論
        c_客 = [0.0] * n + [1.0]  # 最小化 v

        # 不等式約束：對每個主方策略 i，sum_j A[i,j] * q_j ≤ v
        # → sum_j A[i,j] * q_j - v ≤ 0
        A_ub_客 = [[0.0] * (n + 1) for _ in range(m)]
        for i in range(m):
            for j in range(n):
                A_ub_客[i][j] = A[i][j]
            A_ub_客[i][n] = -1.0
        b_ub_客 = [0.0] * m

        # 等式約束：sum_j q_j = 1
        A_eq_客 = [[1.0] * n + [0.0]]
        b_eq_客 = [1.0]

        bounds_客 = [(0.0, None)] * n + [(None, None)]

        res_客 = _simplex_lp(c_客, A_ub=A_ub_客, b_ub=b_ub_客, A_eq=A_eq_客, b_eq=b_eq_客, bounds=bounds_客)

        if res_客.success:
            p_客 = [max(0.0, v) for v in res_客.x[:n]]
            s_客 = sum(p_客)
            p_客 = [v / s_客 for v in p_客] if s_客 > 0 else [1.0 / n] * n
        else:
            p_客 = [1.0 / n] * n

        return game_value, p_主, p_客

    # ------------------------------------------------------------------
    # 公開方法：運籌博弈分析報告
    # ------------------------------------------------------------------

    def 分析報告(self) -> dict[str, Any]:
        """
        生成完整的運籌博弈分析報告。

        整合古法太乙神數推演與現代博弈論分析，輸出包含：
          - 零和支付矩陣（古法兵法格局映射）
          - 主方 / 客方最優混合策略概率分佈
          - 博弈均衡值（期望支付值）
          - 線性規劃最大期望勝率求解結果
          - 主方最優純策略建議
          - 太乙局數、太乙落宮、主客筭旺衰等古法參數摘要

        此處以古法太乙神數「主客相剋」與「兵法吉凶」為本，
        輔以現代博弈論 Nash 均衡（Nash Equilibrium）與運籌學線性規劃報告原理。

        回傳
        ----
        dict[str, Any]
            含以下鍵：
              - 主方策略列 : list[str]
              - 客方策略列 : list[str]
              - 支付矩陣 : list[list[float]]
              - 主方均衡策略 : list[float]  （Nash 混合策略概率）
              - 客方均衡策略 : list[float]  （Nash 混合策略概率）
              - 博弈均衡值 : float           （期望支付值，正值主方有利）
              - 主方最優純策略 : str          （概率最大之純策略）
              - 客方最優純策略 : str
              - 古法推主客相闗 : str          （原始古法結論）
              - 主方勝率判斷 : str            （量化解讀）
              - LP最大勝率 : dict             （線性規劃最優化結果）
              - 太乙局數摘要 : dict           （局數、遁法、三才理年）
              - 太乙落宮 : int               （太乙所在宮位）
              - 八宮旺衰狀態 : str           （太乙落宮之旺衰狀態）
        """
        # 線性規劃：求主方「最大期望勝率」
        # 此處以古法兵法「選擇最優計策」思想為本，輔以現代運籌學線性規劃（LP）最優化原理
        lp結果 = self._LP最優主策略()

        # 主方勝率量化解讀
        if self.博弈均衡值 > 1.0:
            勝率判斷 = "主方大勝（博弈均衡值顯著正值，主方策略佔優）"
        elif self.博弈均衡值 > 0:
            勝率判斷 = "主方小勝（博弈均衡值略正，主方略佔優勢）"
        elif self.博弈均衡值 == 0:
            勝率判斷 = "主客均勢（博弈均衡值為零，雙方勢均力敵）"
        elif self.博弈均衡值 > -1.0:
            勝率判斷 = "客方小勝（博弈均衡值略負，客方略佔優勢）"
        else:
            勝率判斷 = "客方大勝（博弈均衡值顯著負值，客方策略佔優）"

        主方最優純策略索引 = max(range(len(self.主方均衡策略)), key=lambda i: self.主方均衡策略[i])
        客方最優純策略索引 = max(range(len(self.客方均衡策略)), key=lambda i: self.客方均衡策略[i])

        # 太乙局數摘要
        局數, 遁法, 三才理年 = self._解析太乙局數()
        局式 = self._pan.get("局式")
        太乙局數摘要: dict[str, Any] = {
            "局數": 局數,
            "遁法": f"{遁法}遁" if 遁法 else "未知",
            "三才理年": 三才理年 or "未知",
            "局式文字": 局式.get("文", "") if isinstance(局式, dict) else "",
        }

        # 太乙落宮旺衰
        落宮 = self._解析太乙落宮()
        八宮 = self._pan.get("八宮旺衰")
        落宮旺衰狀態 = ""
        if isinstance(八宮, dict) and 落宮:
            落宮旺衰狀態 = str(八宮.get(落宮, ""))

        return {
            "主方策略列": 主方策略列,
            "客方策略列": 客方策略列,
            "支付矩陣": [list(row) for row in self.支付矩陣],
            "主方均衡策略": [round(float(p), 4) for p in self.主方均衡策略],
            "客方均衡策略": [round(float(p), 4) for p in self.客方均衡策略],
            "博弈均衡值": round(self.博弈均衡值, 4),
            "主方最優純策略": 主方策略列[主方最優純策略索引],
            "客方最優純策略": 客方策略列[客方最優純策略索引],
            "古法推主客相闗": self._pan.get("推主客相闗法", "無"),
            "主方勝率判斷": 勝率判斷,
            "LP最大勝率": lp結果,
            "太乙局數摘要": 太乙局數摘要,
            "太乙落宮": 落宮,
            "八宮旺衰狀態": 落宮旺衰狀態,
        }

    def _LP最優主策略(self) -> dict[str, Any]:
        """
        以線性規劃求主方在四大兵法中的「最大期望勝率」最優混合比例。

        問題設定：
          假設客方採用最不利於主方的策略（worst-case），
          主方如何分配四大兵法策略的使用比例，以最大化期望支付？
          此即 maximin 問題，等價於 Nash 均衡主方解。

        此處以古法「擇優而從，避害趨利」兵法思想為本，
        輔以現代運籌學線性規劃（LP）最大化期望收益原理。

        回傳
        ----
        dict[str, Any]
            含最優策略比例、最大期望支付值及策略建議文字。
        """
        A = self.支付矩陣
        m = len(A)
        n = len(A[0])
        # 與 Nash 均衡主方 LP 等價，直接使用已求得結果
        比例 = {主方策略列[i]: round(float(self.主方均衡策略[i]), 4) for i in range(m)}
        最優索引 = max(range(len(self.主方均衡策略)), key=lambda i: self.主方均衡策略[i])
        主要策略 = 主方策略列[最優索引]

        # 融合太乙局數與落宮資訊於建議文字
        局數, 遁法, 三才理年 = self._解析太乙局數()
        落宮 = self._解析太乙落宮()
        局數描述 = ""
        if 局數 > 0:
            局數描述 = f"（{遁法}遁{局數}局"
            if 三才理年:
                局數描述 += f"、{三才理年}"
            if 落宮 != 0:  # 0 = unknown/not applicable; valid palaces are 1-9
                局數描述 += f"、太乙落{落宮}宮"
            局數描述 += "）"

        建議文字 = (
            f"依太乙推主客相闗法、七大兵法、太乙局數與落宮{局數描述}，"
            f"結合現代博弈論 Nash 均衡，"
            f"主方最適策略為「{主要策略}」"
            f"（配置比例 {比例[主要策略] * 100:.1f}%），"
            f"最大期望支付值為 {self.博弈均衡值:.4f}。"
        )
        return {
            "最優策略比例": 比例,
            "最大期望支付值": round(self.博弈均衡值, 4),
            "主要建議策略": 主要策略,
            "建議文字": 建議文字,
        }

    def 格局摘要文字(self) -> str:
        """
        生成供 AI 提示詞使用的博弈分析摘要文字（繁體中文）。

        此處以古法術語為主，融合現代博弈論量化結果，
        適合作為 AI 系統提示或排盤分析附錄。

        回傳
        ----
        str
            可直接嵌入提示詞的摘要段落。
        """
        報告 = self.分析報告()
        lp = 報告["LP最大勝率"]

        主均衡_str = "、".join(
            f"{名}:{概率 * 100:.1f}%" for 名, 概率 in zip(主方策略列, 報告["主方均衡策略"], strict=True)
        )
        客均衡_str = "、".join(
            f"{名}:{概率 * 100:.1f}%" for 名, 概率 in zip(客方策略列, 報告["客方均衡策略"], strict=True)
        )

        # 太乙局數與落宮摘要行
        局數摘要 = 報告.get("太乙局數摘要", {})
        局式文字 = 局數摘要.get("局式文字", "")
        落宮 = 報告.get("太乙落宮", 0)
        旺衰 = 報告.get("八宮旺衰狀態", "")

        lines = [
            "【運籌博弈分析（太乙古法 × Nash 均衡）】",
            f"古法推主客相闗：{報告['古法推主客相闗']}",
        ]
        if 局式文字:
            局式行 = f"太乙局數：{局式文字}"
            if 局數摘要.get("三才理年") and 局數摘要["三才理年"] != "未知":
                局式行 += f"（{局數摘要['三才理年']}）"
            lines.append(局式行)
        if 落宮 != 0:  # 0 = unknown/not applicable; valid palaces are 1-9
            落宮行 = f"太乙落宮：第{落宮}宮"
            if 旺衰:
                落宮行 += f"（{旺衰}）"
            lines.append(落宮行)
        lines += [
            f"博弈均衡值（期望支付）：{報告['博弈均衡值']}",
            f"主方勝率判斷：{報告['主方勝率判斷']}",
            f"主方 Nash 均衡混合策略：{主均衡_str}",
            f"客方 Nash 均衡混合策略：{客均衡_str}",
            f"主方最優純策略：{報告['主方最優純策略']}",
            f"客方最優純策略：{報告['客方最優純策略']}",
            f"線性規劃建議：{lp['建議文字']}",
        ]
        return "\n".join(lines)
